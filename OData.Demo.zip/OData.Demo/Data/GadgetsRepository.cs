﻿using Dapper.Builder;
using Dapper.Builder.Core;
using Dapper.Builder.Services;
using Microsoft.AspNetCore.Http.Extensions;
using OData.Demo.Data;
using OData.Demo.Data.Entities;
using Snowflake.Data.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace OData.Demo.Data
{
    class GadgetsRepository : IGadgetsRepository
    {
        private SnowflakeQueryBuilder<Gadgets> _query;
        public GadgetsRepository(IQueryBuilder<Gadgets> queryBuilder)
        {
            _query = (SnowflakeQueryBuilder<Gadgets>?)queryBuilder;
        }

        public GadgetsRepository()
        {
            //_query = queryBuilder;
        }

        //public async Task<IEnumerable<Gadgets>> GetSomeSimpleStuff()
        //{
        //    //_query = new SnowflakeDbCommandBuilder();

        //    using (SnowflakeDbConnection snowflakeDbConnection = new SnowflakeDbConnection())
        //    {
        //        snowflakeDbConnection.ConnectionString = "account=ib65413.central-india.azure;user=SUJAY; password=Sujay@9860;ROLE=ACCOUNTADMIN; db =TEST_SNOWFLAKE;";
        //        snowflakeDbConnection.Open();

        //        SnowflakeDbDataAdapter snowflakeDbDataAdapter = new SnowflakeDbDataAdapter("select * from Gadgets",snowflakeDbConnection);
        //        DataSet dataSet = new DataSet();
        //        snowflakeDbDataAdapter.Fill(dataSet);


        //        return await _query.Columns(
        //                nameof(Gadgets.Id),
        //                nameof(Gadgets.Cost))
        //            .SortDescending(sc => sc.Id).ExecuteAsync();
        //        //snowflakeDbConnection.Close();
        //    }
        //}

        public async Task<IEnumerable<Gadgets>> GetSomeSimpleStuff()
        {
            QueryResult queryResult = _query.GetQueryString();
            //queryResult.ToString();

            return await _query.Columns(
               nameof(Gadgets.Id),
               nameof(Gadgets.Brand))
           .SortDescending(sc => sc.Id).ExecuteAsync();
        }
    }
}
